[<< back to main index](../README.md) 

Lab 1.1 : Hands on With Scala
===========================

These are 'mini labs'  ; embedded in section-1 of slides.