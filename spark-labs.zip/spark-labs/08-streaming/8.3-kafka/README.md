<link rel='stylesheet' href='../../assets/css/main.css'/>

[<< back to main index](../../README.md) 

Lab 8.3 - Spark Streaming With Kafka
====================================

### Overview
Integrating Kafka and Spark streaming

### Depends On 
None

### Run time
2 hours


* Step 1 : [Setup kafka](1-kafka-setup.md)
* Step 2 : [Do streaming](2-streaming.md)
